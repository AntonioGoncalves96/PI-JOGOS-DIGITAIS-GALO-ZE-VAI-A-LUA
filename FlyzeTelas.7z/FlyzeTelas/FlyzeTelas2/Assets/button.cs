﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class button : MonoBehaviour {

	// Use this for initialization
	void Start () { Application.LoadLevel("Level1");
		
		
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
