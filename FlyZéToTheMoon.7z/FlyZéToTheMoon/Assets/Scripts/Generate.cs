﻿using UnityEngine;
using UnityEditorInternal;
using UnityEngine.SceneManagement;
public class Generate : MonoBehaviour
{
	public GameObject rocks;
	//public GameObject nuvens;
	int score = 0;


	// Use this for initialization
	void Start()
	{
		InvokeRepeating("CreateObstacle", 1f, 1.5f);
	}

	// Update is called once per frame
	void OnGUI () 
	{
		GUI.color = Color.black;
		GUILayout.Label(" Score: " + score.ToString());
	}

	void CreateObstacle()
	{
		Instantiate(rocks);
	//	Instantiate(nuvens);
		score++;

		//if (score == 0) {
		//	rocks = GameObject.FindGameObjectsWithTag["Madeiras"];
	//	}

		//if(score == 6 ){
			//rocks = GameObject.FindWithTag("Madeiras2");
			
		//}
	//	if(score == 50){
	//		SceneManager.LoadScene (2);
			
	//	}
	}

}