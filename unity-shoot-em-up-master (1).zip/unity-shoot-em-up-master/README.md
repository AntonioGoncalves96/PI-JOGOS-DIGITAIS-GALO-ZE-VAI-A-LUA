A shoot'em up 2d game made with unity 4.3
=========================================

It's a repository for my first experience creating a 2d game with Unity 4.3. 
This project was made to reproduce the game [The Great Paper Adventure](http://dmayance.com/the-great-paper-adventure-of/) 
and following this [tutorial](http://pixelnest.io/tutorials/2d-game-unity/), with some changes.

The original source can be found [here](https://github.com/pixelnest/tutorial-2d-game-unity/). 

My thanks to [Pixelnest Studios](http://pixelnest.io/) and specially to [@valryon](http://dmayance.com/).
